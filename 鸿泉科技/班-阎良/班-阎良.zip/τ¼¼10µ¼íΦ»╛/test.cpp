#include <iostream>
using namespace std;
int main() { 
int  n=9;
while(n>6)  
{ 
n--;
cout<<n;
}
}
