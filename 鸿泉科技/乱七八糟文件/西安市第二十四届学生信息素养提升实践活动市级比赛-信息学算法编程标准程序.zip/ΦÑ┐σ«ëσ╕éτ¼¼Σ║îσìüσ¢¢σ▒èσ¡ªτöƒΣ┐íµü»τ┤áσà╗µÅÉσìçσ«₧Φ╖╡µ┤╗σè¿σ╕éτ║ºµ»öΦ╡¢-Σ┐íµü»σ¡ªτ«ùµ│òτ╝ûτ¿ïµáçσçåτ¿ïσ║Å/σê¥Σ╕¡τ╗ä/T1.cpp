/*
选购冰激凌 数学-排列组合
*/
#include <bits/stdc++.h>
using namespace std;
int main() {
	long long n;
	cin >> n;
	n = 3 * pow(2, n - 3);
	cout << n << endl;
	return 0;
}
