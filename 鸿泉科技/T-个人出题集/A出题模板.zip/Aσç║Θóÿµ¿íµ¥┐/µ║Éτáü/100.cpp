#include <bits/stdc++.h>
using namespace std;
int main() {
	int n;
		
	return 0;
}
