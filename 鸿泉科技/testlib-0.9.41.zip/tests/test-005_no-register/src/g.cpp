#include "testlib.h"

int main(int argc, char* argv[]) {
    int n = 10;
    println(n);
    println(rnd.perm(n, 1));
}
