#ifndef _INIT_H_
#define _INIT_H_

#include "common.h"

void init();

#endif
