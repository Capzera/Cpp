#include "common.h"
#include "construct.h"

int main(){
	system("title    ն Ʊϵͳ");
	cout<<"  ӭ   뺽 ն Ʊϵͳ";
	getch();
	init();
	start(1);
	return 0;
}
