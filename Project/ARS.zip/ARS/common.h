#ifndef _COMMON_H_
#define _COMMON_H_

#include <conio.h>
#include <fstream>
#include <bits/stdc++.h>
#include <windows.h>
#include <vector>

using namespace std;

struct administrator{
	string id;
	string name;
	string tel;
	string pwd;
};

#endif //commom.h
